![avatar](https://github.com/leanchess/leanchess.github.io/raw/master/images/lc.png)

# LeanChess

The world's smallest chess program

## Building from source

```
tasm lc
tlink /t lc
```

## Thanks

Isaac Garz�n
